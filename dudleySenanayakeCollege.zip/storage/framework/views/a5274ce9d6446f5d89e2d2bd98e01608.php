<section class="page-title style_two">
    <div class="bg_layer" style="background-image: url(<?php echo e(asset('assets/frontend/images/background/bg-image-08.jpg')); ?>);"></div>
    <div class="container">
        <div class="content-box">
            <ul class="bread-crumb">
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li class="current"><?php echo e($breadcrumbTitle); ?></li>
            </ul>
            <div class="title centred white_color">
                <h2><?php echo e($breadcrumbTitle); ?></h2>
                <?php if(!empty($breadcrumbDescription)): ?>
                    <p><?php echo e($breadcrumbDescription); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\projects\school\site\1\dudleySenanayakeCollege\resources\views/partials/frontend/breadcrumb.blade.php ENDPATH**/ ?>