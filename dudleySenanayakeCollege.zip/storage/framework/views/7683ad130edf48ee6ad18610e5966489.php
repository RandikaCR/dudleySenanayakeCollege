<?php $__env->startSection('page_title'); ?>
    All Events
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Events</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">DSC Admin</a></li>
                        <li class="breadcrumb-item active">Events</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header_buttons'); ?>
    <div class="row">
        <div class="col-sm-12 d-flex justify-content-end mb-3">
            <a href="<?php echo e(url('admin/events/create')); ?>" class="btn btn-primary">
                <span class="mdi mdi-plus-box me-2"></span>
                Add New
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-body">
                    <form method="GET" action="">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-sm-5">
                                <label>Search</label>
                                <input class="form-control" type="text" name="keyword" placeholder="Enter keyword here...." value="<?php echo e($keyword); ?>">
                            </div>
                            

                            <div class="col-sm-3 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary">
                                    <span class="mdi mdi-magnify me-2"></span>
                                    Search
                                </button>
                                <a href="<?php echo e(url('admin/events')); ?>" class="btn btn-outline-dark waves-effect waves-light ms-2">
                                    <span class="mdi mdi-restore me-2"></span>
                                    Clear
                                </a>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">All Products</h4>
                    <div class="flex-shrink-0">
                    </div>
                </div><!-- end card header -->

                <div class="card-body">
                    <div class="live-preview">
                        <div class="row">
                            <div class="col-xl-612">
                                <div class="table-responsive mt-4 mt-xl-0">
                                    <table class="table table-hover table-striped align-middle table-nowrap mb-0">
                                        <thead>
                                        <tr>
                                            <th class="text-center" scope="col">
                                                <p class="mb-0">ID</p>
                                            </th>
                                            <th scope="col" style="width: 10%;">
                                                <p class="mb-0"></p>
                                            </th>
                                            <th scope="col" style="width: 50%;">
                                                <p class="mb-0">Event Title</p>
                                            </th>
                                            <th class="text-center" scope="col">
                                                <p class="mb-0">Category</p>
                                            </th>
                                            <th class="text-center" scope="col">
                                                <p class="mb-0">Status</p>
                                            </th>
                                            <th class="text-end" scope="col">
                                                <p class="mb-0">Actions</p>
                                            </th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr id="row-<?php echo e($event->id); ?>">
                                                <td class="fw-medium text-center">
                                                    <p class="mb-0"><?php echo e($event->id); ?></p>
                                                </td>
                                                <td>
                                                    <div class="bg-light rounded p-1">
                                                        <img src="<?php echo e(asset('assets/common/images/uploads/events/' .$event->primary_image)); ?>" class="img-fluid d-block" alt="Img">
                                                    </div>
                                                </td>
                                                <td>
                                                    <p class="mb-1"><?php echo e($event->en_title); ?></p>
                                                    <p class="mb-1 text-muted"><?php echo e($event->si_title); ?></p>
                                                    <p class="mb-0"><?php echo e($event->ta_title); ?></p>
                                                </td>
                                                <td class="text-center">
                                                    <p class="mb-0"><?php echo e($event->event_category->event_category); ?></p>
                                                </td>
                                                <td class="text-center">
                                                    <p class="mb-0"><span class="badge <?php echo e($event->status()->class); ?>"><?php echo e($event->status()->text); ?></span></p>
                                                </td>
                                                <td class="text-end">
                                                    <div class="d-flex justify-content-end align-items-center">
                                                        <div class="form-check form-switch form-switch-success form-switch-md">
                                                            <input class="form-check-input status" data-id="<?php echo e($event->id); ?>" type="checkbox" role="switch"  <?php echo e(($event->status == 1) ? 'checked': ''); ?> >
                                                        </div>
                                                        <div>
                                                            <a href="<?php echo e(url('events/' . $event->slug)); ?>" target="_blank" class="btn btn-primary btn-sm waves-effect waves-light" data-bs-toggle="tooltip" data-bs-placement="top" title="View"><span class="mdi mdi-magnify"></span></a>
                                                            <a href="<?php echo e(route('backend.events.edit', $event->uuid)); ?>" class="btn btn-primary btn-sm waves-effect waves-light" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit"><span class="mdi mdi-pencil"></span></a>
                                                            <a href="javascript:void(0);" class="btn btn-danger btn-sm waves-effect waves-light delete" data-id="<?php echo e($event->id); ?>" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"><span class="mdi mdi-delete"></span></a>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!--end col-->
                        </div>
                        <!--end row-->

                        <div class="mt-5">
                            
                            <?php echo $events->links('vendor.pagination.backend'); ?>

                        </div>
                    </div>
                </div><!-- end card-body -->
            </div><!-- end card -->
        </div>
        <!-- end col -->
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <!--jquery cdn-->
    <script src="<?php echo e(asset('assets/backend/packages/code.jquery.com/jquery-3.6.0.min.js')); ?>" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <!--select2 cdn-->
    <script src="<?php echo e(asset('assets/backend/packages/cdn.jsdelivr.net/npm/select2%404.1.0-rc.0/dist/js/select2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/backend/js/pages/select2.init.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_scripts'); ?>

    <script>
        $(document).ready(function (){

            $('.table').on('click', '.delete', function ($e){
                $e.preventDefault();
                $this = $(this);
                $id = $($this).data('id');

                Swal.fire({
                    title: "Are you sure?",
                    text: "You want to delete this!",
                    icon: "warning",
                    showCancelButton: !0,
                    showLoaderOnConfirm: true,
                    confirmButtonText: "Yes, Do it!",
                    cancelButtonText: "No, cancel!",
                    confirmButtonClass: "btn btn-primary w-xs me-2 mt-2",
                    cancelButtonClass: "btn btn-danger w-xs mt-2",
                    buttonsStyling: !1,
                    showCloseButton: !0,
                }).then((result) => {
                    if (result.isConfirmed) {

                        setTimeout(function() {
                            $.ajax({
                                url: "<?php echo e(route('backend.events.delete')); ?>",
                                type: 'POST',
                                data: {
                                    id: $id,
                                    _token: csrf_token()
                                },
                                dataType: 'json',
                                beforeSend: function ($jqXHR, $obj) {
                                    Swal.fire({
                                        title: "Processing...",
                                        text: "Please wait",
                                        imageUrl: "<?php echo e(asset('assets/common/images/ajax-loader.gif')); ?>",
                                        showConfirmButton: false,
                                        allowOutsideClick: false
                                    });
                                },
                                success: function ($response, $textStatus, $jqXHR) {
                                    Swal.fire('Done!', 'Image has been deleted!', 'success');

                                    $($this).parent().parent().fadeOut('slow');
                                    setTimeout(function (){
                                        $($this).parent().parent().remove();
                                    },1000);
                                },
                                error: function ($jqXHR, $textStatus, $errorThrown) {
                                    Swal.fire('Oops...', 'Something went wrong with the System!', 'error');
                                }
                            });

                        }, 50);
                    }
                });

            });

            $('.table').on('change', '.status', function (){
                $id = $(this).data('id');
                $url = "<?php echo e(route('backend.events.status')); ?>";
                $rowId = '#row-' + $id;
                $.ajax({
                    url: $url,
                    dataType: 'json',
                    data: {
                        "id": $id,
                        "_token": csrf_token()
                    },
                    method: 'POST',
                    beforeSend: function ($jqXHR, $obj) {

                    },
                    success: function ($res, $textStatus, $jqXHR) {
                        $($rowId).find('.badge').removeClass('bg-success bg-warning').addClass($res.class);
                        $($rowId).find('.badge').html($res.text);
                    },
                    error: function ($jqXHR, $textStatus, $errorThrown) {

                    }
                });
            });

        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\school\site\1\dudleySenanayakeCollege\resources\views/backend/events/index.blade.php ENDPATH**/ ?>