<?php
    $breadcrumbTitle = $event->en_title;
    $breadcrumbDescription = '';
?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php echo $__env->make('partials.frontend.breadcrumb', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <section class="blog_listing_section sec_padding_150">
        <div class="container">
            <div class="row">
                <div class="col-xl-8 col-lg-12">
                    <div class="blog_block_two mb_60">
                        <div class="inner_box">

                            <figure class="blog_image">
                                <div id="bootstrap-gallery-carousel" class="carousel slide">
                                    <div class="carousel-inner" id="image-carousel">
                                        <?php
                                            $no = 0;
                                        ?>
                                        <?php $__currentLoopData = $event->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="carousel-item <?php echo e($no == 0 ? 'active' : ''); ?>" data-src="<?php echo e(asset('assets/common/images/uploads/events/' . $img->image)); ?>">
                                                <img src="<?php echo e(asset('assets/common/images/uploads/events/' . $img->image)); ?>" class="d-block w-100" alt="<?php echo e($event->en_title); ?>" />
                                            </div>
                                            <?php
                                                $no++;
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <button class="carousel-control-prev" type="button" data-bs-target="#bootstrap-gallery-carousel" data-bs-slide="prev">
                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Previous</span>
                                    </button>
                                    <button class="carousel-control-next" type="button" data-bs-target="#bootstrap-gallery-carousel" data-bs-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Next</span>
                                    </button>
                                </div>
                            </figure>
                            <div class="lower_content">
                                <div class="tag-list-area">
                                    <div class="social-links">
                                        <ul>
                                            <li><a href="#"><img src="<?php echo e(asset('assets/frontend/images/icons/facebook.png')); ?>" alt=""></a></li>
                                            <li><a href="#"><img src="<?php echo e(asset('assets/frontend/images/icons/instagram.png')); ?>" alt=""></a></li>
                                        </ul>
                                    </div>
                                    <ul class="post_info">
                                        
                                        <li><a href="#"><i class="flaticon-calendar"></i> <?php echo e(dateFormat($event->created_at)); ?></a></li>
                                    </ul>
                                </div>

                                <h4 class="my-4 fw-bold"><?php echo e($event->en_title); ?></h4>

                                <?php echo $event->en_content; ?>

                            </div>
                            <div class="tag-list-area">
                                <div class="social-links">
                                    <h4>Social Network:</h4>
                                    <ul>
                                        <li><a href="#"><img src="<?php echo e(asset('assets/frontend/images/icons/facebook.png')); ?>" alt=""></a></li>
                                        <li><a href="#"><img src="<?php echo e(asset('assets/frontend/images/icons/instagram.png')); ?>" alt=""></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <div class="col-xl-4 col-lg-12">
                    <div class="blog_sidebar_area">
                        <div class="sidebar_widget popular_event_widget mb_40">
                            <h4 class="event_sidebar_title">Lates Events</h4>
                            <?php $__currentLoopData = $latest_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="event_block_four mb_25">
                                    <div class="event_inner_box">
                                        <div class="date-inner">
                                            <div class="date_box">
                                                <a href="<?php echo e(url('event/' . $ln->slug )); ?>">
                                                    <img src="<?php echo e(asset('assets/common/images/uploads/events/' . $ln->primary_image)); ?>" alt="">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="event-content">
                                            <h6><a href="<?php echo e(url('event/' . $ln->slug )); ?>"><?php echo e($ln->en_title); ?></a></h6>
                                            <ul class="event_info">
                                                <li><i class="flaticon-clock-1"></i> <?php echo e(dateFormat($ln->created_at)); ?></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="sidebar_widget categories-widget mb_40">
                            <h4 class="event_sidebar_title">Categories</h4>
                            <ul class="categories_checkbox">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <label for="styled-checkbox-1"><?php echo e($category->event_category); ?> <span>(<?php echo e($category->count); ?>)</span></label>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function (){

            lightGallery(document.getElementById('image-carousel'), {
                thumbnail: true,
            });


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\school\site\1\dudleySenanayakeCollege\resources\views/frontend/events/view.blade.php ENDPATH**/ ?>