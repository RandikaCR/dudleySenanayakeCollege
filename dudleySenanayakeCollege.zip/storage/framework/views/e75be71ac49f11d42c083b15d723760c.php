<?php if($paginator->hasPages()): ?>
    <div class="d-flex justify-content-center mt-20">
        <ul class="pagination">
            
            <?php if($paginator->onFirstPage()): ?>
                <li class="paginate_button page-item previous disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                    <a href="#" class="page-link">Previous</a>
                </li>
            <?php else: ?>
                <li class="paginate_button page-item previous">
                    <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" class="page-link" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">Previous</a>
                </li>
            <?php endif; ?>

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <li class="paginate_button page-item disabled">
                        <a href="#" class="page-link"><?php echo e($element); ?></a>
                    </li>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li class="paginate_button page-item active" aria-current="page">
                                <a href="#" class="page-link"><?php echo e($page); ?></a>
                            </li>
                        <?php else: ?>
                            <li class="paginate_button page-item">
                                <a href="<?php echo e($url); ?>" class="page-link"><?php echo e($page); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li class="paginate_button page-item next">
                    <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="page-link" rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">Next</a>
                </li>
            <?php else: ?>
                <li class="paginate_button page-item next disabled">
                    <a href="#" class="page-link" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">Next</a>
                </li>
            <?php endif; ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\projects\school\site\1\dudleySenanayakeCollege\resources\views/vendor/pagination/backend.blade.php ENDPATH**/ ?>