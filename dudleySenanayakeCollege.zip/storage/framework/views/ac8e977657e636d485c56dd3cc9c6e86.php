<?php if($paginator->hasPages()): ?>
    <div class="pagination-wrapper">
        <ul class="pagination">
            
            <?php if($paginator->onFirstPage()): ?>
                <li class="disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                    <a href="#" class="page-link"><i class="flaticon-right-arrow-1"></i></a>
                </li>
            <?php else: ?>
                <li class="">
                    <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" class="page-link" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>"><i class="flaticon-right-arrow-1"></i></a>
                </li>
            <?php endif; ?>

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <li class=" disabled">
                        <a href="javascript:void(0);" class=""><?php echo e($element); ?></a>
                    </li>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li class="" aria-current="page">
                                <a href="javascript:void(0);" class="current"><?php echo e($page); ?></a>
                            </li>
                        <?php else: ?>
                            <li class="">
                                <a href="<?php echo e($url); ?>" class=""><?php echo e($page); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li class="">
                    <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="" rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>"><i class="flaticon-right-arrow-1"></i></a>
                </li>
            <?php else: ?>
                <li class="disabled">
                    <a href="javascript:void(0);" class="" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>"><i class="flaticon-right-arrow-1"></i></a>
                </li>
            <?php endif; ?>
        </ul>
    </div>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\projects\school\site\1\dudleySenanayakeCollege\resources\views/vendor/pagination/frontend.blade.php ENDPATH**/ ?>