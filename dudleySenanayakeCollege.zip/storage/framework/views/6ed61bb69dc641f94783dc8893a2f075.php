<!-- Jquery Plugins -->
<script src="<?php echo e(asset('assets/frontend/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/fontawesome.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/jquery.fancybox.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/appear.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/countdown.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/jquery.nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/owl.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/wow.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/validation.js')); ?>"></script>
<!-- End Jequery Plugins -->

<!-- Main Js -->
<script src="<?php echo e(asset('assets/frontend/js/main.js')); ?>"></script>
<!-- End Main Js -->
<?php /**PATH C:\xampp2\htdocs\projects\school\site\1\dudleySenanayakeCollege\resources\views/partials/frontend/script.blade.php ENDPATH**/ ?>