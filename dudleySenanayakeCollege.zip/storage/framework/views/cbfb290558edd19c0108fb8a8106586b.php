<!doctype html>
<html lang="en" data-layout="vertical" data-topbar="dark" data-sidebar="dark" data-sidebar-size="lg" data-sidebar-image="none">

<head>
    <?php echo $__env->make('partials.backend.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body>

<!-- Begin page -->
<div id="layout-wrapper">

    <?php echo $__env->make('partials.backend.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- ========== App Menu ========== -->
    <?php echo $__env->make('partials.backend.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Left Sidebar End -->
    <!-- Vertical Overlay-->
    <div class="vertical-overlay"></div>

    <!-- ============================================================== -->
    <!-- Start right Content here -->
    <!-- ============================================================== -->
    <div class="main-content">

        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <?php echo $__env->yieldContent('breadcrumb'); ?>
                <!-- end page title -->

                <?php echo $__env->yieldContent('header_buttons'); ?>

                <?php echo $__env->yieldContent('content'); ?>

            </div>
            <!-- container-fluid -->
        </div>
        <!-- End Page-content -->

        <?php echo $__env->make('partials.backend.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    </div>
    <!-- end main content-->

</div>
<!-- END layout-wrapper -->



<!--start back-to-top-->
<button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top">
    <i class="ri-arrow-up-line"></i>
</button>
<!--end back-to-top-->

<?php echo $__env->make('partials.backend.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\projects\school\site\1\dudleySenanayakeCollege\resources\views/layouts/backend.blade.php ENDPATH**/ ?>