<meta charset="utf-8" />
<title><?php echo $__env->yieldContent('page_title'); ?> :: DSC Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta property="title" content="Dudley Senanayake College. Colombo 05" />
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="author" content="www.dudleysenanayakecollege.lk">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<!-- App favicon -->
<link rel="icon" href="<?php echo e(asset('assets/common/images/favicon.png')); ?>" type="image/png"/>

<?php echo $__env->yieldContent('styles'); ?>

<!-- Sweet Alert css-->
<link href="<?php echo e(asset('assets/backend/libs/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" />

<link rel="stylesheet" href="<?php echo e(asset('assets/backend/libs/jquery-toast-plugin-master/src/jquery.toast.css')); ?>">



<!-- Layout config Js -->
<script src="<?php echo e(asset('assets/backend/js/layout.js')); ?>"></script>
<!-- Bootstrap Css -->
<link href="<?php echo e(asset('assets/backend/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="<?php echo e(asset('assets/backend/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="<?php echo e(asset('assets/backend/css/app.min.css')); ?>" rel="stylesheet" type="text/css" />
<!-- custom Css-->
<link href="<?php echo e(asset('assets/backend/css/custom.min.css')); ?>" rel="stylesheet" type="text/css" />

<?php echo $__env->yieldContent('css'); ?>
<?php /**PATH C:\xampp\htdocs\projects\school\site\1\dudleySenanayakeCollege\resources\views/partials/backend/head.blade.php ENDPATH**/ ?>