<?php
    $breadcrumbTitle = 'Events';
    $breadcrumbDescription = '';
?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php echo $__env->make('partials.frontend.breadcrumb', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <section class="blog_section_home_one blog_page sec_padding_140">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-4 col-xl-6 col-md-6 col-sm-12 block_block">
                        <div class="blog_block_one mb_30">
                            <div class="inner_box">
                                <figure class="blog_image">
                                    <a href="<?php echo e(url('event/' . $event->slug )); ?>"><img src="<?php echo e(asset('assets/common/images/uploads/events/' . $event->primary_image)); ?>" alt=""></a>
                                    <div class="link_btn"><a href="<?php echo e(url('event/' . $event->slug )); ?>">Read More</a></div>
                                </figure>
                                <div class="lower_content">
                                    <ul class="post_info">
                                        
                                        <li><a href="#"><i class="flaticon-calendar"></i> <?php echo e(dateFormat($event->created_at)); ?></a></li>
                                    </ul>
                                    <h4><a href="<?php echo e(url('event/' . $event->slug )); ?>"><?php echo e($event->en_title); ?></a></h4>
                                    <p><?php echo e(stringLimitLength($event->en_content, 300)); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>


            <?php echo $events->links('vendor.pagination.frontend'); ?>

        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\school\site\1\dudleySenanayakeCollege\resources\views/frontend/events/index.blade.php ENDPATH**/ ?>