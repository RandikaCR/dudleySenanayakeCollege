<?php
    $breadcrumbTitle = 'Login';
    $breadcrumbDescription = '';
?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php echo $__env->make('partials.frontend.breadcrumb', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <section class="login_section sec_padding_70">
        <div class="container">
            <div class="register_inner">

                <form class="register_form" action="<?php echo e(route('login')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <?php if($errors->any()): ?>
                        <div class="row">
                            <div class="col-sm-12">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-danger">
                                        <?php echo e($error); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <h3 class="title">login</h3>
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <div class="icon"><img src="<?php echo e(asset('assets/frontend/images/icons/user.png')); ?>" alt=""></div>
                        <input type="text" id="email" placeholder="Type your email address" name="email" required="">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <div class="icon"><img src="<?php echo e(asset('assets/frontend/images/icons/lock.png')); ?>" alt=""></div>
                        <input type="password" id="password" placeholder="Type your password" name="password" required="">
                    </div>
                    <div class="form-group centred">
                        <div class="forget_pass"><a href="#">Forget  your password?</a></div>
                        <button type="submit" class="button-style-two">Login <i class="flaticon-next"></i></button>
                    </div>
                </form>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\school\site\1\dudleySenanayakeCollege\resources\views/auth/login.blade.php ENDPATH**/ ?>