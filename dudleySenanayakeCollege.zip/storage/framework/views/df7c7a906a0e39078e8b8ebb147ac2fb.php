<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('partials.frontend.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<!-- page wrapper -->
<body class="boxed_wrapper">

<?php echo $__env->make('partials.frontend.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->yieldContent('breadcrumb'); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('partials.frontend.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<!-- Scroll to Top -->
<button class="scroll-top scroll-to-target" data-target="html">
    <i class="flaticon-next"></i>
</button>
<!--End Scroll to Top -->


<?php echo $__env->make('partials.frontend.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>
<!-- End Page Wrapper -->

</html>
<?php /**PATH C:\xampp\htdocs\projects\school\site\1\dudleySenanayakeCollege\resources\views/layouts/frontend.blade.php ENDPATH**/ ?>