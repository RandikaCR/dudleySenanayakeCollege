<?php
    $breadcrumbTitle = 'News';
    $breadcrumbDescription = '';
?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php echo $__env->make('partials.frontend.breadcrumb', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <section class="blog_section_home_one blog_page sec_padding_140">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $all_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-4 col-xl-6 col-md-6 col-sm-12 block_block">
                        <div class="blog_block_one mb_30">
                            <div class="inner_box">
                                <figure class="blog_image">
                                    <a href="<?php echo e(url('news/' . $news->slug )); ?>"><img src="<?php echo e(asset('assets/common/images/uploads/news/' . $news->primary_image)); ?>" alt=""></a>
                                    <div class="link_btn"><a href="<?php echo e(url('news/' . $news->slug )); ?>">Read More</a></div>
                                </figure>
                                <div class="lower_content">
                                    <ul class="post_info">
                                        
                                        <li><a href="#"><i class="flaticon-calendar"></i> <?php echo e(dateFormat($news->created_at)); ?></a></li>
                                    </ul>
                                    <h4><a href="<?php echo e(url('news/' . $news->slug )); ?>"><?php echo e($news->en_title); ?></a></h4>
                                    <p><?php echo e(stringLimitLength($news->en_content, 300)); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>


            <?php echo $all_news->links('vendor.pagination.frontend'); ?>

        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\school\site\1\dudleySenanayakeCollege\resources\views/frontend/news/index.blade.php ENDPATH**/ ?>