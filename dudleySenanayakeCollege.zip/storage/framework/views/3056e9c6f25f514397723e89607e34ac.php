<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <?php echo e(date('Y', time())); ?> © Dudley Senanayake College @ Admin.
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\projects\school\site\1\dudleySenanayakeCollege\resources\views/partials/backend/footer.blade.php ENDPATH**/ ?>