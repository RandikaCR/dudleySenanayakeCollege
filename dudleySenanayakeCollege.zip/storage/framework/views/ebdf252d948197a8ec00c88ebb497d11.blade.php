## Tailwind 3

- Always use Tailwind CSS v3 - verify you're using only classes supported by this version.
