<?php

return [
    'previous' => '',
    'next' => 'Next Sinhala',
];
