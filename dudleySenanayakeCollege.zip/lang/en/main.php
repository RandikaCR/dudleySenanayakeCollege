<?php

return [
    'previous' => '',
    'next' => 'Next',
];
