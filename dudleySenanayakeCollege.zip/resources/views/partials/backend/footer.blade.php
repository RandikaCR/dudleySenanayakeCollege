<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                {{ date('Y', time()) }} © Dudley Senanayake College @ Admin.
            </div>
        </div>
    </div>
</footer>
